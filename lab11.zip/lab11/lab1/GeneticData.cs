namespace Lab1;

public struct GeneticData
{
    public string protein;
    public string organism; 
    public string amino_acids; 
}